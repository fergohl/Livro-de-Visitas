const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
});

app.post('/api/visit', (req, res) => {
  const { name, city, phone, email } = req.body;
  const now = new Date();
  const sql = "INSERT INTO visitors (name, city, phone, email, visited_at) VALUES (?, ?, ?, ?, ?)";
  db.execute(sql, [name, city, phone, email, now], (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ success: true });
  });
});

app.get('/api/visitors', (req, res) => {
  const { period } = req.query;
  let sql = "SELECT * FROM visitors";
  if (period === 'daily') sql += " WHERE DATE(visited_at) = CURDATE()";
  if (period === 'monthly') sql += " WHERE MONTH(visited_at) = MONTH(CURDATE()) AND YEAR(visited_at) = YEAR(CURDATE())";
  if (period === 'yearly') sql += " WHERE YEAR(visited_at) = YEAR(CURDATE())";
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));